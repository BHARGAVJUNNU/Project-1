UPDATE Bikes SET rental_price = 15 WHERE bike_id = 1;

INSERT INTO Customers (customer_name, phone_number, email) VALUES ('John Doe', '123-456-7890', 'john.doe@example.com');

DELETE FROM Rentals WHERE rental_id = 3;

UPDATE Rentals SET return_date = '2023-04-24' WHERE rental_id = 2;
